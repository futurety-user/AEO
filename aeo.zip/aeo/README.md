# AEO Audit Tool

A Python-based Answer Engine Optimization audit tool that crawls a website, analyzes its content for AEO readiness, and generates actionable reports.

## Project Structure

```
aeo/
├── main.py                 # CLI entry point — orchestrates the full audit pipeline
├── requirements.txt        # Python dependencies
├── crawler/                # Fetches pages from a target website (respects robots.txt, rate limits)
├── sitemap_parser/         # Parses XML sitemaps and sitemap indexes to discover URLs
├── analyzer/               # Scores pages on AEO factors: structured data, headings, FAQ markup, etc.
├── prompts/                # LLM prompt templates used by the analyzer for content evaluation
├── pdf_generator/          # Builds branded PDF reports from analysis results
├── reports/                # Report data models and formatters (JSON, summary objects)
├── output/                 # Default directory for generated report files (gitignored)
└── utils/                  # Shared helpers: logging, config, HTTP, text normalization
```

## Quick Start

```bash
pip install -r requirements.txt
python main.py https://example.com
```
