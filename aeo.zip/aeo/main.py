"""AEO Audit Tool - Main entry point."""

import argparse
import logging
import sys

import os

from sitemap_parser import run as run_sitemap_parser
from crawler import run as run_crawler
from analyzer import run as run_analyzer, run_aggregator


def main():
    parser = argparse.ArgumentParser(
        description="AEO (Answer Engine Optimization) Audit Tool"
    )
    parser.add_argument("url", help="Domain or sitemap URL (e.g. https://example.com or https://example.com/sitemap.xml)")
    parser.add_argument(
        "--output", "-o", default="output", help="Output directory for reports"
    )
    parser.add_argument(
        "--format",
        choices=["pdf", "json", "both"],
        default="both",
        help="Report output format",
    )
    parser.add_argument(
        "--skip-sitemap", action="store_true",
        help="Skip sitemap parsing and use existing output/clean_urls.csv",
    )
    parser.add_argument(
        "--skip-crawl", action="store_true",
        help="Skip the crawl step",
    )
    parser.add_argument(
        "--skip-analyze", action="store_true",
        help="Skip the LLM analysis step",
    )
    parser.add_argument(
        "--analyze-limit", type=int, default=None,
        help="Analyze only the first N crawled pages (default: all)",
    )
    parser.add_argument(
        "--batch-size", type=int, default=10,
        help="Pages per batch; progress checkpoint saved after each batch (default: 10)",
    )
    parser.add_argument(
        "--concurrency", type=int, default=3,
        help="Max parallel API calls within a batch (default: 3)",
    )
    parser.add_argument(
        "--max-retries", type=int, default=2,
        help="Max retries per page before marking it as terminally failed (default: 2)",
    )
    parser.add_argument(
        "--force", action="store_true",
        help="Re-analyze pages even if a saved audit already exists",
    )
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    )

    print(f"Starting AEO audit for: {args.url}")

    if not args.skip_sitemap:
        clean_urls = run_sitemap_parser(args.url, output_dir=args.output)
        print(f"Sitemap parse complete — {len(clean_urls)} clean URL(s) saved to {args.output}/clean_urls.csv")

    if not args.skip_crawl:
        stats = run_crawler(
            input_csv=os.path.join(args.output, "clean_urls.csv"),
            output_dir=args.output,
        )
        print(
            f"Crawl complete — {stats['succeeded']} ok / {stats['failed']} failed; "
            f"pages in {stats['pages_dir']}, summary at {stats['summary_csv']}"
        )

    if not args.skip_analyze:
        analysis_stats = run_analyzer(
            pages_dir=os.path.join(args.output, "pages"),
            output_dir=os.path.join(args.output, "analysis"),
            limit=args.analyze_limit,
            batch_size=args.batch_size,
            concurrency=args.concurrency,
            max_retries=args.max_retries,
            force=args.force,
        )

        aggregate_result = run_aggregator(analysis_dir=os.path.join(args.output, "analysis"))
        s = aggregate_result["summary"]
        print(
            f"Aggregation complete — {s['total_pages']} pages, "
            f"{s['pattern_count']} pattern(s), "
            f"{s['unique_issue_page_count']} page(s) with unique issues. "
            f"Summary: {os.path.join(args.output, 'analysis', '_audit_summary.json')}"
        )

    # TODO: report pipeline stages (PDF)


if __name__ == "__main__":
    main()
