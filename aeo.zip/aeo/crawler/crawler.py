"""Page crawler — fetches each URL and extracts structured AEO-relevant data."""

import csv
import hashlib
import json
import logging
import os
import re
import time
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

HEADERS = {
    "User-Agent": "AEO-Audit-Bot/1.0 (+https://github.com/aeo-audit)"
}

REQUEST_TIMEOUT = 30
MAX_RETRIES = 3
RETRY_BACKOFF = 2  # seconds; doubled each retry
POLITENESS_DELAY = 0.5  # seconds between requests

# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------

def fetch_html(url: str) -> tuple[str | None, int | None]:
    """Fetch *url* with retries and return ``(html, status_code)``.

    Returns ``(None, status)`` on failure. ``status`` is ``None`` if no response was received.
    """
    last_status: int | None = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            resp = requests.get(
                url, headers=HEADERS, timeout=REQUEST_TIMEOUT, allow_redirects=True,
            )
            last_status = resp.status_code
            resp.raise_for_status()
            return resp.text, resp.status_code
        except requests.HTTPError as exc:
            logger.warning("HTTP %s on %s (attempt %d/%d)", last_status, url, attempt, MAX_RETRIES)
            if last_status is not None and 400 <= last_status < 500 and last_status != 429:
                # Client errors (except rate-limit) won't recover from retrying
                break
        except requests.RequestException as exc:
            logger.warning("Request error on %s (attempt %d/%d): %s", url, attempt, MAX_RETRIES, exc)

        if attempt < MAX_RETRIES:
            sleep_for = RETRY_BACKOFF * (2 ** (attempt - 1))
            time.sleep(sleep_for)

    logger.error("Failed to fetch %s after %d attempt(s)", url, MAX_RETRIES)
    return None, last_status

# ---------------------------------------------------------------------------
# Extractors
# ---------------------------------------------------------------------------

def _text(tag) -> str:
    return tag.get_text(strip=True) if tag else ""


def extract_title(soup: BeautifulSoup) -> str:
    return _text(soup.find("title"))


def extract_meta_description(soup: BeautifulSoup) -> str:
    tag = soup.find("meta", attrs={"name": re.compile(r"^description$", re.I)})
    return tag.get("content", "").strip() if tag else ""


def extract_canonical(soup: BeautifulSoup) -> str:
    tag = soup.find("link", attrs={"rel": lambda v: v and "canonical" in v})
    return tag.get("href", "").strip() if tag else ""


def extract_headings(soup: BeautifulSoup) -> dict[str, list[str]]:
    headings: dict[str, list[str]] = {}
    for level in range(1, 7):
        tag_name = f"h{level}"
        headings[tag_name] = [_text(t) for t in soup.find_all(tag_name) if _text(t)]
    return headings


def extract_jsonld(soup: BeautifulSoup) -> list[dict | list]:
    blocks: list[dict | list] = []
    for script in soup.find_all("script", attrs={"type": "application/ld+json"}):
        raw = script.string or script.get_text()
        if not raw:
            continue
        try:
            blocks.append(json.loads(raw))
        except json.JSONDecodeError as exc:
            logger.debug("Invalid JSON-LD block: %s", exc)
    return blocks


def extract_open_graph(soup: BeautifulSoup) -> dict[str, str]:
    og: dict[str, str] = {}
    for tag in soup.find_all("meta", attrs={"property": re.compile(r"^og:", re.I)}):
        key = tag.get("property", "").strip()
        value = tag.get("content", "").strip()
        if key and value:
            og[key] = value
    return og


def extract_twitter(soup: BeautifulSoup) -> dict[str, str]:
    tw: dict[str, str] = {}
    for tag in soup.find_all("meta", attrs={"name": re.compile(r"^twitter:", re.I)}):
        key = tag.get("name", "").strip()
        value = tag.get("content", "").strip()
        if key and value:
            tw[key] = value
    return tw


def extract_images(soup: BeautifulSoup, base_url: str) -> list[dict[str, str]]:
    images: list[dict[str, str]] = []
    for img in soup.find_all("img"):
        src = img.get("src", "").strip()
        if not src:
            continue
        images.append({
            "src": urljoin(base_url, src),
            "alt": (img.get("alt") or "").strip(),
            "has_alt": bool((img.get("alt") or "").strip()),
        })
    return images


def extract_internal_links(soup: BeautifulSoup, base_url: str) -> list[str]:
    base_host = urlparse(base_url).netloc.lower()
    links: set[str] = set()
    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        if not href or href.startswith(("mailto:", "tel:", "javascript:", "#")):
            continue
        absolute = urljoin(base_url, href)
        if urlparse(absolute).netloc.lower() == base_host:
            links.add(absolute.split("#")[0])
    return sorted(links)


def extract_word_count(soup: BeautifulSoup) -> int:
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    body = soup.find("body")
    text = body.get_text(" ", strip=True) if body else soup.get_text(" ", strip=True)
    return len(re.findall(r"\b\w+\b", text))


def extract_faq_sections(soup: BeautifulSoup, jsonld_blocks: list) -> list[dict[str, str]]:
    """Pull FAQ Q&A pairs from FAQPage JSON-LD; fall back to common HTML patterns."""
    faqs: list[dict[str, str]] = []

    def _walk_jsonld(node):
        if isinstance(node, list):
            for item in node:
                _walk_jsonld(item)
            return
        if not isinstance(node, dict):
            return
        node_type = node.get("@type")
        if node_type == "FAQPage" or (isinstance(node_type, list) and "FAQPage" in node_type):
            for q in node.get("mainEntity", []) or []:
                if not isinstance(q, dict):
                    continue
                question = (q.get("name") or "").strip()
                answer_obj = q.get("acceptedAnswer") or {}
                if isinstance(answer_obj, list):
                    answer_obj = answer_obj[0] if answer_obj else {}
                answer = (answer_obj.get("text") or "").strip() if isinstance(answer_obj, dict) else ""
                if question:
                    faqs.append({"question": question, "answer": answer, "source": "json-ld"})
        if "@graph" in node:
            _walk_jsonld(node["@graph"])

    for block in jsonld_blocks:
        _walk_jsonld(block)

    if not faqs:
        # Heuristic HTML fallback: <details><summary>Q</summary>A</details>
        for det in soup.find_all("details"):
            summary = det.find("summary")
            if not summary:
                continue
            question = _text(summary)
            answer_parts = [_text(c) for c in det.find_all(recursive=False) if c.name != "summary"]
            faqs.append({
                "question": question,
                "answer": " ".join(p for p in answer_parts if p),
                "source": "html-details",
            })

    return faqs

# ---------------------------------------------------------------------------
# Page-level
# ---------------------------------------------------------------------------

def parse_page(url: str, html: str) -> dict:
    """Extract every AEO-relevant field from one page's HTML."""
    soup = BeautifulSoup(html, "lxml")
    jsonld = extract_jsonld(soup)
    return {
        "url": url,
        "title": extract_title(soup),
        "meta_description": extract_meta_description(soup),
        "canonical_url": extract_canonical(soup),
        "headings": extract_headings(soup),
        "jsonld": jsonld,
        "open_graph": extract_open_graph(soup),
        "twitter_card": extract_twitter(soup),
        "images": extract_images(soup, url),
        "internal_links": extract_internal_links(soup, url),
        "word_count": extract_word_count(soup),
        "faqs": extract_faq_sections(soup, jsonld),
    }


def _slugify_url(url: str) -> str:
    """Build a stable, filesystem-safe filename from a URL."""
    parsed = urlparse(url)
    path = (parsed.path or "/").strip("/").replace("/", "_") or "index"
    path = re.sub(r"[^A-Za-z0-9._-]", "_", path)[:120]
    digest = hashlib.md5(url.encode("utf-8")).hexdigest()[:8]
    return f"{path}__{digest}.json"


def save_page_json(page_data: dict, pages_dir: str) -> str:
    os.makedirs(pages_dir, exist_ok=True)
    filename = _slugify_url(page_data["url"])
    path = os.path.join(pages_dir, filename)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(page_data, f, indent=2, ensure_ascii=False)
    return path

# ---------------------------------------------------------------------------
# Input / orchestration
# ---------------------------------------------------------------------------

def read_urls_csv(csv_path: str) -> list[str]:
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"Input URL list not found: {csv_path}")
    urls: list[str] = []
    with open(csv_path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            url = (row.get("url") or "").strip()
            if url:
                urls.append(url)
    return urls


def _summary_row(url: str, page: dict | None, status: int | None, error: str = "") -> dict:
    if page is None:
        return {
            "url": url,
            "status": status if status is not None else "",
            "title": "",
            "meta_description_length": 0,
            "h1_count": 0,
            "h2_count": 0,
            "word_count": 0,
            "image_count": 0,
            "images_missing_alt": 0,
            "internal_link_count": 0,
            "jsonld_block_count": 0,
            "has_faq": False,
            "has_canonical": False,
            "has_open_graph": False,
            "has_twitter_card": False,
            "error": error,
        }
    return {
        "url": url,
        "status": status if status is not None else "",
        "title": page["title"],
        "meta_description_length": len(page["meta_description"]),
        "h1_count": len(page["headings"].get("h1", [])),
        "h2_count": len(page["headings"].get("h2", [])),
        "word_count": page["word_count"],
        "image_count": len(page["images"]),
        "images_missing_alt": sum(1 for i in page["images"] if not i["has_alt"]),
        "internal_link_count": len(page["internal_links"]),
        "jsonld_block_count": len(page["jsonld"]),
        "has_faq": bool(page["faqs"]),
        "has_canonical": bool(page["canonical_url"]),
        "has_open_graph": bool(page["open_graph"]),
        "has_twitter_card": bool(page["twitter_card"]),
        "error": "",
    }


SUMMARY_FIELDS = [
    "url", "status", "title", "meta_description_length",
    "h1_count", "h2_count", "word_count", "image_count", "images_missing_alt",
    "internal_link_count", "jsonld_block_count",
    "has_faq", "has_canonical", "has_open_graph", "has_twitter_card", "error",
]


def write_summary_csv(rows: list[dict], path: str) -> str:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=SUMMARY_FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    return os.path.abspath(path)


def run(
    input_csv: str = "output/clean_urls.csv",
    output_dir: str = "output",
    delay: float = POLITENESS_DELAY,
) -> dict:
    """Full pipeline: read URLs -> fetch -> extract -> save JSON + summary CSV.

    Returns a dict with run statistics.
    """
    logger.info("=" * 60)
    logger.info("Crawler started — input: %s", input_csv)
    logger.info("=" * 60)

    urls = read_urls_csv(input_csv)
    logger.info("Loaded %d URL(s) to crawl", len(urls))

    pages_dir = os.path.join(output_dir, "pages")
    failed_log_path = os.path.join(output_dir, "failed_urls.log")
    os.makedirs(output_dir, exist_ok=True)

    summary_rows: list[dict] = []
    failed: list[tuple[str, str]] = []
    success_count = 0

    for idx, url in enumerate(urls, start=1):
        logger.info("[%d/%d] %s", idx, len(urls), url)
        html, status = fetch_html(url)

        if html is None:
            error = f"fetch_failed (status={status})"
            summary_rows.append(_summary_row(url, None, status, error))
            failed.append((url, error))
            if delay:
                time.sleep(delay)
            continue

        try:
            page = parse_page(url, html)
            save_page_json(page, pages_dir)
            summary_rows.append(_summary_row(url, page, status))
            success_count += 1
        except Exception as exc:  # extraction shouldn't kill the whole run
            logger.exception("Failed to parse %s: %s", url, exc)
            summary_rows.append(_summary_row(url, None, status, f"parse_error: {exc}"))
            failed.append((url, f"parse_error: {exc}"))

        if delay:
            time.sleep(delay)

    summary_path = write_summary_csv(summary_rows, os.path.join(output_dir, "crawl_summary.csv"))

    if failed:
        with open(failed_log_path, "w", encoding="utf-8") as f:
            for u, err in failed:
                f.write(f"{u}\t{err}\n")
        logger.warning("Logged %d failure(s) to %s", len(failed), failed_log_path)

    stats = {
        "total": len(urls),
        "succeeded": success_count,
        "failed": len(failed),
        "pages_dir": os.path.abspath(pages_dir),
        "summary_csv": summary_path,
    }

    logger.info("=" * 60)
    logger.info("Crawler complete — %d ok / %d failed (of %d)", success_count, len(failed), len(urls))
    logger.info("Pages saved to: %s", stats["pages_dir"])
    logger.info("Summary CSV:    %s", stats["summary_csv"])
    logger.info("=" * 60)
    return stats
