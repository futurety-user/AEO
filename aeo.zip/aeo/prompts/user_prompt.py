"""Builds the per-page user message sent to Claude."""

import json


def build_user_prompt(page_data: dict, page_type: str) -> str:
    """Trim per-page extracted data into a compact JSON payload for analysis."""
    images = page_data.get("images", []) or []
    image_summary = {
        "count": len(images),
        "missing_alt": sum(1 for i in images if not i.get("has_alt")),
        "sample_alts": [i.get("alt", "") for i in images[:8] if i.get("has_alt")],
    }

    internal_links = page_data.get("internal_links", []) or []
    link_summary = {
        "count": len(internal_links),
        "sample": internal_links[:15],
    }

    trimmed = {
        "url": page_data.get("url", ""),
        "title": page_data.get("title", ""),
        "meta_description": page_data.get("meta_description", ""),
        "canonical_url": page_data.get("canonical_url", ""),
        "headings": page_data.get("headings", {}),
        "word_count": page_data.get("word_count", 0),
        "jsonld": page_data.get("jsonld", []),
        "open_graph": page_data.get("open_graph", {}),
        "twitter_card": page_data.get("twitter_card", {}),
        "images": image_summary,
        "internal_links": link_summary,
        "faqs": page_data.get("faqs", []),
    }

    return (
        f"page_type: {page_type}\n\n"
        "Analyze the page below per the system prompt and return the structured JSON audit.\n\n"
        "Page data:\n"
        "```json\n"
        f"{json.dumps(trimmed, indent=2, ensure_ascii=False)}\n"
        "```"
    )
