"""JSON schema for the structured per-page analysis output."""

CATEGORY_KEYS = [
    "title_quality",
    "meta_description_quality",
    "heading_hierarchy",
    "faq_readiness",
    "schema_coverage",
    "image_alt_coverage",
    "aeo_readiness",
    "content_structure",
    "readability",
    "entity_clarity",
    "internal_linking",
    "social_metadata",
]

SEVERITIES = ["high", "medium", "low"]

# A controlled vocabulary of issue codes. The aggregator groups by (page_type, code)
# to detect template-level issues — Claude is instructed in the system prompt to
# pick from this list whenever a finding maps cleanly to one.
ISSUE_CODES = [
    # title_quality
    "missing_title", "short_title", "long_title", "generic_title",
    # meta_description_quality
    "missing_meta_description", "short_meta_description",
    "long_meta_description", "generic_meta_description",
    # heading_hierarchy
    "missing_h1", "multiple_h1", "generic_headings",
    "skipped_heading_levels", "nav_headings_in_main",
    # faq_readiness
    "missing_faq_content", "missing_faqpage_schema",
    # schema_coverage
    "missing_article_schema", "missing_organization_schema",
    "missing_breadcrumb_schema", "missing_itemlist_schema",
    "missing_person_schema", "incomplete_schema_properties",
    # image_alt_coverage
    "low_image_alt_coverage", "generic_image_alt",
    # aeo_readiness
    "no_scannable_format", "no_tldr_or_summary", "not_citable_format",
    # content_structure
    "no_main_answer_upfront", "thin_content", "poor_section_delineation",
    # readability
    "long_sentences_or_paragraphs", "jargon_without_definition",
    # entity_clarity
    "ambiguous_entities", "missing_entity_schema",
    # internal_linking
    "too_few_internal_links", "too_many_internal_links",
    "generic_anchor_text",
    # social_metadata
    "missing_og_image", "incomplete_open_graph",
    "mismatched_og_title", "missing_twitter_card",
    # fallback for anything outside the vocabulary
    "other",
]


_ISSUE_DEF = {
    "type": "object",
    "properties": {
        "code": {"type": "string"},
        "category": {"type": "string", "enum": CATEGORY_KEYS},
        "severity": {"type": "string", "enum": SEVERITIES},
        "description": {"type": "string"},
        "why_it_matters": {"type": "string"},
        "location": {"type": "string"},
        "fix_recommendation": {"type": "string"},
        "copy_paste_snippet": {"type": "string"},
    },
    "required": [
        "code", "category", "severity", "description",
        "why_it_matters", "location", "fix_recommendation",
        "copy_paste_snippet",
    ],
    "additionalProperties": False,
}


OUTPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "url": {"type": "string"},
        "overall_score": {"type": "number"},
        "summary": {"type": "string"},
        "strengths": {
            "type": "array",
            "items": {"type": "string"},
        },
        "category_scores": {
            "type": "object",
            "properties": {k: {"type": "number"} for k in CATEGORY_KEYS},
            "required": CATEGORY_KEYS,
            "additionalProperties": False,
        },
        "issues": {
            "type": "array",
            "items": {"$ref": "#/$defs/issue"},
        },
    },
    "required": ["url", "overall_score", "summary", "strengths", "category_scores", "issues"],
    "additionalProperties": False,
    "$defs": {"issue": _ISSUE_DEF},
}
