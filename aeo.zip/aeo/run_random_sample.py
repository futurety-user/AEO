"""Pick N random URLs from clean_urls.csv, crawl + analyze + aggregate."""

import csv
import json
import logging
import os
import random
import sys
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
)

from crawler import run as run_crawler
from analyzer import run as run_analyzer, run_aggregator

SEED = 42
SAMPLE_SIZE = 10
SAMPLE_CSV = "output/clean_urls_sample10.csv"


def load_urls(path: str) -> list[str]:
    with open(path, encoding="utf-8-sig", newline="") as f:
        return [r["url"].strip() for r in csv.DictReader(f) if r.get("url")]


def already_analyzed_urls(analysis_dir: str) -> set[str]:
    urls: set[str] = set()
    for f in Path(analysis_dir).glob("*.json"):
        if f.name.startswith("_"):
            continue
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            if data.get("url") and "issues" in data:
                urls.add(data["url"])
        except (json.JSONDecodeError, OSError):
            pass
    return urls


def main() -> None:
    all_urls = load_urls("output/clean_urls.csv")
    done = already_analyzed_urls("output/analysis")
    pool = [u for u in all_urls if u not in done]

    print(f"Total clean URLs:    {len(all_urls)}")
    print(f"Already analyzed:    {len(done)}")
    print(f"Unanalyzed pool:     {len(pool)}")

    if len(pool) < SAMPLE_SIZE:
        print(f"Pool smaller than {SAMPLE_SIZE} — using all {len(pool)}")

    random.seed(SEED)
    sample = random.sample(pool, min(SAMPLE_SIZE, len(pool)))
    print(f"\nSampled {len(sample)} URLs (seed={SEED}):")
    for url in sample:
        print(f"  - {url}")

    Path("output").mkdir(exist_ok=True)
    with open(SAMPLE_CSV, "w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["url"])
        for url in sample:
            writer.writerow([url])

    print(f"\n=== Crawling {len(sample)} URLs ===")
    run_crawler(input_csv=SAMPLE_CSV, output_dir="output", delay=0.5)

    if not os.environ.get("ANTHROPIC_API_KEY"):
        print("\nANTHROPIC_API_KEY not set — stopping before analyze step.")
        sys.exit(0)

    print(f"\n=== Analyzing (batch_size=5, concurrency=3) ===")
    run_analyzer(
        pages_dir="output/pages",
        output_dir="output/analysis",
        batch_size=5,
        concurrency=3,
        max_retries=2,
    )

    print(f"\n=== Aggregating ===")
    run_aggregator(analysis_dir="output/analysis")


if __name__ == "__main__":
    main()
