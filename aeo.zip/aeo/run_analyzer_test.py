"""One-page verbose analyzer test — shows prompt, raw response, scores, recommendations, and saved file path."""

import json
import logging
import os
import sys
from pathlib import Path

import anthropic

from prompts import SYSTEM_PROMPT, OUTPUT_SCHEMA, build_user_prompt
from analyzer.analyzer import MODEL, MAX_TOKENS


def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(levelname)-8s  %(message)s",
    )

    page_files = sorted(Path("output/pages").glob("*.json"))
    if not page_files:
        print("No crawled pages found in output/pages/", file=sys.stderr)
        sys.exit(1)

    page_file = page_files[0]
    page_data = json.loads(page_file.read_text(encoding="utf-8"))
    user_prompt = build_user_prompt(page_data)

    print("=" * 72)
    print("PAGE SELECTED FOR TEST")
    print("=" * 72)
    print(f"  File: {page_file.name}")
    print(f"  URL:  {page_data['url']}")
    print()

    print("=" * 72)
    print(f"SYSTEM PROMPT  ({len(SYSTEM_PROMPT)} chars)")
    print("=" * 72)
    print(SYSTEM_PROMPT)
    print()

    print("=" * 72)
    print(f"USER PROMPT  ({len(user_prompt)} chars)")
    print("=" * 72)
    print(user_prompt)
    print()

    if not os.environ.get("ANTHROPIC_API_KEY"):
        print("=" * 72)
        print("ANTHROPIC_API_KEY is not set — stopping before API call.")
        print("Set it and re-run to see the response and saved file:")
        print("  PowerShell:  $env:ANTHROPIC_API_KEY = 'sk-ant-...'")
        print("  Then:        python run_analyzer_test.py")
        print("=" * 72)
        sys.exit(0)

    print("=" * 72)
    print(f"CALLING CLAUDE  (model={MODEL}, max_tokens={MAX_TOKENS}, effort=high, adaptive thinking)")
    print("=" * 72)

    client = anthropic.Anthropic()
    with client.messages.stream(
        model=MODEL,
        max_tokens=MAX_TOKENS,
        thinking={"type": "adaptive"},
        output_config={
            "effort": "high",
            "format": {"type": "json_schema", "schema": OUTPUT_SCHEMA},
        },
        system=[{
            "type": "text",
            "text": SYSTEM_PROMPT,
            "cache_control": {"type": "ephemeral"},
        }],
        messages=[{"role": "user", "content": user_prompt}],
    ) as stream:
        message = stream.get_final_message()

    raw_text = next((b.text for b in message.content if b.type == "text"), "")

    print()
    print("=" * 72)
    print("RAW CLAUDE RESPONSE")
    print("=" * 72)
    print(raw_text)
    print()

    usage = message.usage
    print("=" * 72)
    print("USAGE")
    print("=" * 72)
    print(f"  input_tokens:               {usage.input_tokens}")
    print(f"  output_tokens:              {usage.output_tokens}")
    print(f"  cache_read_input_tokens:    {getattr(usage, 'cache_read_input_tokens', 0) or 0}")
    print(f"  cache_creation_input_tokens:{getattr(usage, 'cache_creation_input_tokens', 0) or 0}")
    print(f"  stop_reason:                {message.stop_reason}")
    print()

    result = json.loads(raw_text)

    print("=" * 72)
    print("SCORES")
    print("=" * 72)
    print(f"  Overall: {result['overall_score']:.1f} / 10")
    print()
    for cat_name, cat in result["categories"].items():
        print(f"  {cat_name:30s}  {cat['score']:.1f}")
    print()

    print("=" * 72)
    print("SUMMARY")
    print("=" * 72)
    print(f"  {result['summary']}")
    print()

    print("=" * 72)
    print("RECOMMENDATIONS  (by category)")
    print("=" * 72)
    for cat_name, cat in result["categories"].items():
        if cat["recommendations"]:
            print(f"\n  [{cat_name}]  (score {cat['score']:.1f})")
            for rec in cat["recommendations"]:
                print(f"    - {rec}")
    print()

    print("=" * 72)
    print("COPY-PASTE FIXES")
    print("=" * 72)
    any_fix = False
    for cat_name, cat in result["categories"].items():
        for fix in cat.get("copy_paste_fixes", []):
            any_fix = True
            print(f"\n  [{cat_name}]  {fix['description']}")
            print(f"    {fix['snippet']}")
    if not any_fix:
        print("  (none)")
    print()

    out_dir = Path("output/analysis")
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / page_file.name
    out_path.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")

    print("=" * 72)
    print("SAVED ANALYSIS")
    print("=" * 72)
    print(f"  {out_path.resolve()}")
    print(f"  ({out_path.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
