"""Sitemap parser — discovers, fetches, extracts, filters, and deduplicates sitemap URLs."""

import csv
import logging
import os
import re
from urllib.parse import urlparse, urlunparse

import requests
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

FILTER_PATTERNS = [
    r"/tag/",
    r"/category/",
    r"/archive/",
    r"/search/",
    r"/page/\d+",
    r"/author/",
    r"/feed/",
    r"\?s=",
    r"\?p=",
    r"/wp-json/",
    r"/wp-admin/",
    r"/wp-content/",
    r"/attachment/",
    r"/comment-page-",
    r"#",
]

_filter_re = re.compile("|".join(FILTER_PATTERNS), re.IGNORECASE)

HEADERS = {
    "User-Agent": "AEO-Audit-Bot/1.0 (+https://github.com/aeo-audit)"
}

REQUEST_TIMEOUT = 30

SITEMAP_FALLBACKS = [
    "/sitemap.xml",
    "/sitemap_index.xml",
]

# ---------------------------------------------------------------------------
# URL helpers
# ---------------------------------------------------------------------------

def validate_url(url: str) -> str | None:
    """Return a cleaned, absolute URL or None if invalid.

    Adds ``https://`` when no scheme is present. Rejects non-HTTP(S) schemes.
    """
    url = url.strip()
    if not url:
        return None

    parsed = urlparse(url)

    if not parsed.scheme:
        url = "https://" + url
        parsed = urlparse(url)

    if parsed.scheme not in ("http", "https"):
        logger.error("Unsupported scheme %r in URL: %s", parsed.scheme, url)
        return None

    if not parsed.netloc:
        logger.error("Missing domain in URL: %s", url)
        return None

    return urlunparse(parsed)


def _get_base_url(url: str) -> str:
    """Extract ``scheme://host`` from a URL."""
    parsed = urlparse(url)
    return f"{parsed.scheme}://{parsed.netloc}"


def _is_sitemap_url(url: str) -> bool:
    """Heuristic: does the URL path look like it points directly to a sitemap file?"""
    path = urlparse(url).path.lower()
    return path.endswith(".xml") or path.endswith(".xml.gz")

# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------

def _get(url: str, *, allow_redirects: bool = True) -> requests.Response | None:
    """Perform a GET request with redirect/error handling. Returns None on failure."""
    try:
        resp = requests.get(
            url, headers=HEADERS, timeout=REQUEST_TIMEOUT, allow_redirects=allow_redirects,
        )
        if resp.is_redirect or resp.is_permanent_redirect:
            target = resp.headers.get("Location", "")
            logger.info("Redirect: %s -> %s", url, target)
        resp.raise_for_status()
        return resp
    except requests.RequestException as exc:
        logger.debug("GET %s failed: %s", url, exc)
        return None


def fetch_xml(url: str) -> str | None:
    """Download XML content from *url*. Returns the response text or None on failure."""
    resp = _get(url)
    if resp is None:
        logger.error("Failed to fetch sitemap: %s", url)
        return None
    content_type = resp.headers.get("Content-Type", "")
    if "html" in content_type and "xml" not in content_type:
        logger.warning("URL returned HTML instead of XML: %s (Content-Type: %s)", url, content_type)
        return None
    return resp.text

# ---------------------------------------------------------------------------
# Sitemap discovery
# ---------------------------------------------------------------------------

def discover_sitemaps_from_robots(base_url: str) -> list[str]:
    """Parse robots.txt and return any ``Sitemap:`` entries."""
    robots_url = base_url.rstrip("/") + "/robots.txt"
    logger.info("Checking robots.txt: %s", robots_url)

    resp = _get(robots_url)
    if resp is None:
        logger.info("No robots.txt found at %s", robots_url)
        return []

    sitemaps: list[str] = []
    for line in resp.text.splitlines():
        line = line.strip()
        if line.lower().startswith("sitemap:"):
            sitemap_url = line.split(":", 1)[1].strip()
            validated = validate_url(sitemap_url)
            if validated:
                sitemaps.append(validated)
                logger.info("Found sitemap in robots.txt: %s", validated)

    if not sitemaps:
        logger.info("robots.txt exists but contains no Sitemap entries")
    return sitemaps


def _try_fallback_sitemaps(base_url: str) -> list[str]:
    """Probe common sitemap paths and return the ones that respond with XML."""
    found: list[str] = []
    for path in SITEMAP_FALLBACKS:
        candidate = base_url.rstrip("/") + path
        logger.info("Trying fallback sitemap: %s", candidate)
        resp = _get(candidate)
        if resp is not None:
            content_type = resp.headers.get("Content-Type", "")
            if "xml" in content_type or resp.text.strip().startswith("<?xml"):
                logger.info("Discovered sitemap at fallback path: %s", candidate)
                found.append(candidate)
    return found


def discover_sitemaps(input_url: str) -> list[str]:
    """Discover sitemap URLs from a domain or return the input if it's already a sitemap URL.

    Strategy:
    1. If the input looks like a direct sitemap URL (.xml / .xml.gz), use it as-is.
    2. Otherwise treat it as a domain — check robots.txt for Sitemap directives.
    3. If robots.txt yields nothing, try common fallback paths.
    """
    validated = validate_url(input_url)
    if validated is None:
        logger.error("Invalid URL provided: %s", input_url)
        return []

    if _is_sitemap_url(validated):
        logger.info("Input looks like a sitemap URL — using directly: %s", validated)
        return [validated]

    base_url = _get_base_url(validated)
    logger.info("Input appears to be a domain — starting sitemap discovery for %s", base_url)

    sitemaps = discover_sitemaps_from_robots(base_url)
    if sitemaps:
        return sitemaps

    logger.info("No sitemaps in robots.txt — trying fallback paths")
    sitemaps = _try_fallback_sitemaps(base_url)
    if sitemaps:
        return sitemaps

    logger.warning("No sitemap found for %s", base_url)
    return []

# ---------------------------------------------------------------------------
# XML extraction
# ---------------------------------------------------------------------------

def _extract_urls_from_sitemap(xml_text: str) -> list[str]:
    """Pull every <loc> value from a standard <urlset> sitemap."""
    soup = BeautifulSoup(xml_text, "lxml-xml")
    return [loc.text.strip() for loc in soup.find_all("loc")]


def _extract_sitemap_links(xml_text: str) -> list[str]:
    """Pull child sitemap URLs from a <sitemapindex>."""
    soup = BeautifulSoup(xml_text, "lxml-xml")
    index_tag = soup.find("sitemapindex")
    if not index_tag:
        return []
    return [loc.text.strip() for loc in index_tag.find_all("loc")]


def parse_sitemap(sitemap_url: str, *, _depth: int = 0) -> list[str]:
    """Recursively parse a sitemap (or sitemap index) and return all discovered page URLs.

    Handles nested sitemap indexes up to 5 levels deep to avoid infinite loops.
    """
    if _depth > 5:
        logger.warning("Max sitemap nesting depth reached at %s — skipping", sitemap_url)
        return []

    logger.info("Fetching sitemap: %s (depth=%d)", sitemap_url, _depth)
    xml_text = fetch_xml(sitemap_url)
    if xml_text is None:
        return []

    child_sitemaps = _extract_sitemap_links(xml_text)

    if child_sitemaps:
        logger.info("Sitemap index detected — %d child sitemap(s)", len(child_sitemaps))
        all_urls: list[str] = []
        for child_url in child_sitemaps:
            all_urls.extend(parse_sitemap(child_url, _depth=_depth + 1))
        return all_urls

    urls = _extract_urls_from_sitemap(xml_text)
    logger.info("Extracted %d URL(s) from %s", len(urls), sitemap_url)
    return urls

# ---------------------------------------------------------------------------
# Filtering / dedup
# ---------------------------------------------------------------------------

def filter_urls(urls: list[str]) -> list[str]:
    """Remove tag/category/archive/search/pagination and other junk URLs."""
    clean = [u for u in urls if not _filter_re.search(u)]
    removed = len(urls) - len(clean)
    if removed:
        logger.info("Filtered out %d unwanted URL(s)", removed)
    return clean


def deduplicate(urls: list[str]) -> list[str]:
    """Remove duplicates while preserving first-seen order."""
    seen: set[str] = set()
    unique: list[str] = []
    for url in urls:
        normalized = url.rstrip("/")
        if normalized not in seen:
            seen.add(normalized)
            unique.append(url)
    dupes = len(urls) - len(unique)
    if dupes:
        logger.info("Removed %d duplicate URL(s)", dupes)
    return unique

# ---------------------------------------------------------------------------
# CSV output
# ---------------------------------------------------------------------------

def save_to_csv(urls: list[str], output_path: str) -> str:
    """Write the URL list to a CSV file and return the absolute path."""
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["url"])
        for url in urls:
            writer.writerow([url])
    logger.info("Saved %d URL(s) to %s", len(urls), output_path)
    return os.path.abspath(output_path)

# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def run(input_url: str, output_dir: str = "output") -> list[str]:
    """Full pipeline: discover -> fetch -> extract -> filter -> deduplicate -> save CSV.

    *input_url* can be a direct sitemap URL **or** a plain domain.
    Returns the final list of clean URLs.
    """
    logger.info("=" * 60)
    logger.info("Sitemap parse started for: %s", input_url)
    logger.info("=" * 60)

    sitemap_urls = discover_sitemaps(input_url)
    if not sitemap_urls:
        logger.error("No sitemaps discovered — aborting")
        return []

    raw_urls: list[str] = []
    for sitemap_url in sitemap_urls:
        raw_urls.extend(parse_sitemap(sitemap_url))

    logger.info("Total raw URLs discovered: %d", len(raw_urls))

    if not raw_urls:
        logger.warning("Sitemaps were found but contained no URLs")
        return []

    filtered = filter_urls(raw_urls)
    clean = deduplicate(filtered)

    csv_path = os.path.join(output_dir, "clean_urls.csv")
    save_to_csv(clean, csv_path)

    logger.info("=" * 60)
    logger.info("Sitemap parse complete: %d clean URL(s)", len(clean))
    logger.info("=" * 60)
    return clean
