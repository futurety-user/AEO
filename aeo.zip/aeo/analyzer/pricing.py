"""Model pricing and per-call cost estimation."""

# USD per 1M tokens. Cache write = 1.25x input; cache read = 0.1x input.
MODEL_PRICING = {
    "claude-opus-4-7": {
        "input": 5.0,
        "output": 25.0,
        "cache_write": 6.25,
        "cache_read": 0.50,
    },
    "claude-opus-4-6": {
        "input": 5.0,
        "output": 25.0,
        "cache_write": 6.25,
        "cache_read": 0.50,
    },
    "claude-sonnet-4-6": {
        "input": 3.0,
        "output": 15.0,
        "cache_write": 3.75,
        "cache_read": 0.30,
    },
    "claude-haiku-4-5": {
        "input": 1.0,
        "output": 5.0,
        "cache_write": 1.25,
        "cache_read": 0.10,
    },
}


def estimate_cost(usage: dict, model: str) -> dict:
    """Return a breakdown of {input, output, cache_write, cache_read, total} in USD."""
    pricing = MODEL_PRICING.get(model)
    if pricing is None:
        return {"input": 0.0, "output": 0.0, "cache_write": 0.0, "cache_read": 0.0, "total": 0.0}

    breakdown = {
        "input": usage.get("input_tokens", 0) * pricing["input"] / 1_000_000,
        "output": usage.get("output_tokens", 0) * pricing["output"] / 1_000_000,
        "cache_write": usage.get("cache_creation_input_tokens", 0) * pricing["cache_write"] / 1_000_000,
        "cache_read": usage.get("cache_read_input_tokens", 0) * pricing["cache_read"] / 1_000_000,
    }
    breakdown["total"] = sum(breakdown.values())
    return breakdown
