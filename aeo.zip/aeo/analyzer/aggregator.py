"""Aggregate per-page audit JSON into pattern-level recommendations."""

import json
import logging
from collections import Counter, defaultdict
from pathlib import Path

logger = logging.getLogger(__name__)


def _severity_to_priority(severities: list[str]) -> str:
    """Pick a pattern priority from the severities of its constituent issues."""
    counts = Counter(severities)
    if counts.get("high", 0) >= max(1, len(severities) // 2):
        return "high"
    if counts.get("high", 0) >= 1 or counts.get("medium", 0) >= max(1, len(severities) // 2):
        return "medium"
    return "low"


def _build_pattern(page_type: str, code: str, entries: list[tuple[str, dict]]) -> dict:
    """Build a single pattern record from N (url, issue) entries sharing a code."""
    urls = [u for u, _ in entries]
    issues = [iss for _, iss in entries]
    first = issues[0]

    fix_recommendation = first.get("fix_recommendation", "")
    why = first.get("why_it_matters", "")
    snippet = first.get("copy_paste_snippet", "")
    # Prefer a non-empty snippet if the first one is empty
    if not snippet:
        for iss in issues[1:]:
            if iss.get("copy_paste_snippet"):
                snippet = iss["copy_paste_snippet"]
                break

    location = first.get("location", "")
    severities = [iss.get("severity", "medium") for iss in issues]
    priority = _severity_to_priority(severities)

    type_label = page_type.replace("_", " ")
    return {
        "page_type": page_type,
        "issue_code": code,
        "category": first.get("category"),
        "affected_page_count": len(urls),
        "affected_urls": urls,
        "repeated_issue": first.get("description", ""),
        "why_it_matters": why,
        "template_recommendation": (
            f"Template-level issue affecting {len(urls)} {type_label} pages. "
            f"{fix_recommendation}".strip()
        ),
        "where_to_fix": (
            f"{type_label.title()} page template — {location}"
            if location else f"{type_label.title()} page template"
        ),
        "copy_paste_code": snippet,
        "priority": priority,
        "estimated_impact": (
            f"Fixing this template issue will improve {len(urls)} {type_label} pages."
        ),
    }


def aggregate(analysis_dir: str = "output/analysis") -> dict:
    """Scan ``analysis_dir`` for per-page audit JSONs, group repeated issues into patterns.

    Returns a summary dict containing patterns, page-level unique issues, and counts.
    """
    analysis_path = Path(analysis_dir)
    if not analysis_path.exists():
        raise FileNotFoundError(f"Analysis directory not found: {analysis_dir}")

    audits: list[dict] = []
    for f in sorted(analysis_path.glob("*.json")):
        if f.name.startswith("_"):
            continue
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            logger.warning("Skipping unreadable %s: %s", f.name, exc)
            continue
        if "issues" not in data:
            logger.warning("Skipping %s — old schema (no 'issues' array)", f.name)
            continue
        audits.append(data)

    if not audits:
        logger.warning("No conformant audit files found in %s", analysis_dir)
        return {
            "summary": {"total_pages": 0, "page_types": {}, "overall_score_avg": 0.0,
                        "pattern_count": 0, "unique_issue_page_count": 0},
            "patterns": [],
            "page_level_unique_issues": [],
        }

    # Build the (page_type, code) → list[(url, issue)] index
    index: dict[tuple[str, str], list[tuple[str, dict]]] = defaultdict(list)
    for audit in audits:
        page_type = audit.get("page_type", "other")
        url = audit.get("url", "")
        for issue in audit.get("issues", []):
            code = issue.get("code")
            if not code:
                continue
            index[(page_type, code)].append((url, issue))

    # Patterns: any (page_type, code) with ≥2 affected pages
    pattern_keys = {key for key, entries in index.items() if len(entries) >= 2}
    patterns = [_build_pattern(pt, code, index[(pt, code)]) for (pt, code) in pattern_keys]
    # Sort by affected page count (desc), then priority (high first)
    priority_order = {"high": 0, "medium": 1, "low": 2}
    patterns.sort(key=lambda p: (-p["affected_page_count"], priority_order.get(p["priority"], 3)))

    # Page-level uniques: issues NOT in any pattern
    page_level_unique: list[dict] = []
    for audit in audits:
        page_type = audit.get("page_type", "other")
        url = audit.get("url", "")
        unique_issues = [
            iss for iss in audit.get("issues", [])
            if (page_type, iss.get("code")) not in pattern_keys
        ]
        if unique_issues:
            page_level_unique.append({
                "url": url,
                "page_type": page_type,
                "overall_score": audit.get("overall_score"),
                "issues": unique_issues,
            })

    summary = {
        "total_pages": len(audits),
        "page_types": dict(Counter(a.get("page_type", "other") for a in audits)),
        "overall_score_avg": round(
            sum(a.get("overall_score", 0.0) for a in audits) / len(audits), 2
        ),
        "pattern_count": len(patterns),
        "unique_issue_page_count": len(page_level_unique),
    }

    return {
        "summary": summary,
        "patterns": patterns,
        "page_level_unique_issues": page_level_unique,
    }


def run(analysis_dir: str = "output/analysis") -> dict:
    """Run aggregation and write ``_audit_summary.json`` to the same directory."""
    logger.info("=" * 60)
    logger.info("Aggregator started — scanning %s", analysis_dir)
    logger.info("=" * 60)

    result = aggregate(analysis_dir)

    out_path = Path(analysis_dir) / "_audit_summary.json"
    out_path.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")

    summary = result["summary"]
    logger.info(
        "Aggregator complete — %d pages, %d patterns, %d pages with unique issues",
        summary["total_pages"], summary["pattern_count"], summary["unique_issue_page_count"],
    )
    logger.info("Page types: %s", summary["page_types"])
    logger.info("Saved: %s", out_path.resolve())
    logger.info("=" * 60)

    return result
