"""Classify a page into a high-level type from its URL and JSON-LD signals."""

import re
from urllib.parse import urlparse

PAGE_TYPES = [
    "homepage",
    "blog",
    "case_study",
    "service",
    "location",
    "category_archive",
    "contact_about",
    "other",
]


def _collect_jsonld_types(jsonld) -> set[str]:
    """Recursively pull every ``@type`` value out of a parsed JSON-LD payload."""
    found: set[str] = set()

    def _walk(node):
        if isinstance(node, list):
            for item in node:
                _walk(item)
            return
        if not isinstance(node, dict):
            return
        t = node.get("@type")
        if isinstance(t, str):
            found.add(t)
        elif isinstance(t, list):
            found.update(x for x in t if isinstance(x, str))
        if "@graph" in node:
            _walk(node["@graph"])
        for v in node.values():
            if isinstance(v, (list, dict)):
                _walk(v)

    _walk(jsonld)
    return found


_URL_KEYWORD_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("blog", re.compile(r"^(blog|insights|articles?|news|posts?)(/|$)", re.I)),
    ("case_study", re.compile(r"^(case-stud(?:y|ies)|portfolio|projects?|work)(/|$)", re.I)),
    ("service", re.compile(r"^(services?|solutions?|what-we-do|offerings?|products?|features?)(/|$)", re.I)),
    ("location", re.compile(r"^(locations?|offices?|find-us|cities?|stores?)(/|$)", re.I)),
    ("contact_about", re.compile(r"^(contact|about(?:-us)?|team|company|careers?|jobs?)(/|$)", re.I)),
]

_ARCHIVE_PATTERN = re.compile(r"/(category|tag|archive|page/\d+)(/|$)", re.I)

_JSONLD_TYPE_MAP = {
    "AboutPage": "contact_about",
    "ContactPage": "contact_about",
    "Service": "service",
    "Product": "service",
    "LocalBusiness": "location",
    "Place": "location",
}


def classify_page_type(page_data: dict) -> str:
    """Return one of ``PAGE_TYPES`` for *page_data*.

    Decision order:
      1. Empty path → homepage
      2. ``/category/``, ``/tag/``, ``/archive/``, ``/page/N/`` in URL → category_archive
      3. CollectionPage JSON-LD without Article → category_archive
      4. Article / BlogPosting / NewsArticle JSON-LD → blog
      5. URL keyword prefixes (blog/case-study/service/location/contact/about)
      6. JSON-LD type hints (Service, LocalBusiness, AboutPage, ContactPage)
      7. Otherwise → other
    """
    url = page_data.get("url", "")
    path = urlparse(url).path.strip("/")
    jsonld_types = _collect_jsonld_types(page_data.get("jsonld", []))

    if not path:
        return "homepage"

    if _ARCHIVE_PATTERN.search("/" + path):
        return "category_archive"

    if "CollectionPage" in jsonld_types and not (jsonld_types & {"Article", "BlogPosting", "NewsArticle"}):
        return "category_archive"

    if jsonld_types & {"Article", "BlogPosting", "NewsArticle"}:
        return "blog"

    for ptype, pattern in _URL_KEYWORD_PATTERNS:
        if pattern.match(path):
            return ptype

    for jld_type, ptype in _JSONLD_TYPE_MAP.items():
        if jld_type in jsonld_types:
            return ptype

    return "other"
