"""AEO/GEO analyzer — batches, concurrency, checkpointing, resume, and cost tracking."""

import json
import logging
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed, Future
from pathlib import Path

import anthropic

from prompts import SYSTEM_PROMPT, OUTPUT_SCHEMA, build_user_prompt

from .page_type import classify_page_type
from .pricing import estimate_cost
from .progress import Progress

logger = logging.getLogger(__name__)

MODEL = "claude-opus-4-7"
MAX_TOKENS = 32000

DEFAULT_BATCH_SIZE = 10
DEFAULT_CONCURRENCY = 3
DEFAULT_MAX_RETRIES = 2


def _usage_to_dict(usage) -> dict:
    return {
        "input_tokens": int(usage.input_tokens or 0),
        "output_tokens": int(usage.output_tokens or 0),
        "cache_creation_input_tokens": int(getattr(usage, "cache_creation_input_tokens", 0) or 0),
        "cache_read_input_tokens": int(getattr(usage, "cache_read_input_tokens", 0) or 0),
    }


def analyze_page(page_data: dict, client: anthropic.Anthropic) -> tuple[dict, dict]:
    """Call Claude on one page. Returns ``(audit_dict, usage_dict)``."""
    page_type = classify_page_type(page_data)
    user_prompt = build_user_prompt(page_data, page_type)

    with client.messages.stream(
        model=MODEL,
        max_tokens=MAX_TOKENS,
        thinking={"type": "adaptive"},
        output_config={
            "effort": "high",
            "format": {"type": "json_schema", "schema": OUTPUT_SCHEMA},
        },
        system=[{
            "type": "text",
            "text": SYSTEM_PROMPT,
            "cache_control": {"type": "ephemeral"},
        }],
        messages=[{"role": "user", "content": user_prompt}],
    ) as stream:
        message = stream.get_final_message()

    text = next((b.text for b in message.content if b.type == "text"), "")
    if not text:
        raise RuntimeError(f"No text content returned for {page_data.get('url')}")

    result = json.loads(text)
    result["page_type"] = page_type

    usage = _usage_to_dict(message.usage)
    cost = estimate_cost(usage, MODEL)
    result["_usage"] = {**usage, "model": MODEL, "estimated_cost_usd": round(cost["total"], 4)}

    return result, usage


def _format_duration(seconds: float) -> str:
    seconds = int(seconds)
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h}h {m}m {s}s"
    if m:
        return f"{m}m {s}s"
    return f"{s}s"


def _print_runtime_summary(stats: dict) -> None:
    print()
    print("=" * 70)
    print("RUN COMPLETE")
    print("=" * 70)
    print(f"  Pages:      total={stats['total_queued']}, "
          f"succeeded={stats['succeeded']}, "
          f"failed={stats['failed']}, "
          f"skipped={stats['skipped']}")
    print(f"  Wall time:  {_format_duration(stats['wall_seconds'])}  "
          f"(avg {stats['avg_seconds_per_page']:.1f}s/page)")
    print(f"  Tokens:     input={stats['usage_totals']['input_tokens']:,}  "
          f"output={stats['usage_totals']['output_tokens']:,}  "
          f"cache_write={stats['usage_totals']['cache_creation_input_tokens']:,}  "
          f"cache_read={stats['usage_totals']['cache_read_input_tokens']:,}")
    cb = stats["cost_breakdown_usd"]
    print(f"  Cost (USD): ${stats['cost_total_usd']:.4f}")
    print(f"    input:       ${cb['input']:.4f}")
    print(f"    output:      ${cb['output']:.4f}")
    print(f"    cache write: ${cb['cache_write']:.4f}")
    print(f"    cache read:  ${cb['cache_read']:.4f}")
    if stats["failed_urls"]:
        print(f"  Failed URLs (logged to {stats['failed_log_path']}):")
        for url in stats["failed_urls"][:10]:
            print(f"    - {url}")
        if len(stats["failed_urls"]) > 10:
            print(f"    ... and {len(stats['failed_urls']) - 10} more")
    print("=" * 70)


def _process_page(
    page_file: Path,
    output_dir: Path,
    client: anthropic.Anthropic,
) -> tuple[Path, str, dict | None, dict | None, Exception | None]:
    """Worker entrypoint. Returns ``(page_file, url, audit, usage, error)``."""
    try:
        page_data = json.loads(page_file.read_text(encoding="utf-8"))
        url = page_data.get("url", page_file.name)
        audit, usage = analyze_page(page_data, client)
        out_path = output_dir / page_file.name
        out_path.write_text(json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8")
        return page_file, url, audit, usage, None
    except Exception as exc:
        try:
            url = json.loads(page_file.read_text(encoding="utf-8")).get("url", page_file.name)
        except Exception:
            url = page_file.name
        return page_file, url, None, None, exc


def run(
    pages_dir: str = "output/pages",
    output_dir: str = "output/analysis",
    limit: int | None = None,
    batch_size: int = DEFAULT_BATCH_SIZE,
    concurrency: int = DEFAULT_CONCURRENCY,
    max_retries: int = DEFAULT_MAX_RETRIES,
    force: bool = False,
) -> dict:
    """Analyze pages with batching, concurrency, resume, and cost tracking."""
    pages_dir_path = Path(pages_dir)
    output_dir_path = Path(output_dir)
    output_dir_path.mkdir(parents=True, exist_ok=True)

    if not pages_dir_path.exists():
        raise FileNotFoundError(f"Pages directory not found: {pages_dir}")

    all_page_files = sorted(pages_dir_path.glob("*.json"))
    if not all_page_files:
        logger.warning("No page JSON files found in %s", pages_dir)
        return {"total_queued": 0, "succeeded": 0, "failed": 0, "skipped": 0}

    progress_path = output_dir_path / "_progress.json"
    progress = Progress.load_or_create(progress_path)
    backfilled = progress.backfill_existing_audits(output_dir_path)
    if backfilled:
        progress.save()
        logger.info("Backfilled %d already-analyzed page(s) into progress", backfilled)

    failed_log_path = output_dir_path / "_failed.log"

    # Decide what to process
    queue: list[Path] = []
    skipped_count = 0
    for f in all_page_files:
        try:
            url = json.loads(f.read_text(encoding="utf-8")).get("url", "")
        except (json.JSONDecodeError, OSError):
            url = ""
        if not force and url and progress.is_completed(url):
            skipped_count += 1
            continue
        if url and progress.has_failed_terminal(url, max_retries):
            logger.warning("Skipping %s — exhausted retries (attempts=%d)",
                           url, progress.attempt_count(url))
            skipped_count += 1
            continue
        queue.append(f)

    if limit is not None:
        queue = queue[:limit]

    if not os.environ.get("ANTHROPIC_API_KEY"):
        raise RuntimeError(
            "ANTHROPIC_API_KEY environment variable is not set. "
            "Set it (PowerShell: $env:ANTHROPIC_API_KEY = 'sk-ant-...') and re-run."
        )

    client = anthropic.Anthropic()

    logger.info("=" * 60)
    logger.info("Analyzer started — model=%s", MODEL)
    logger.info("Pages on disk: %d  | already done: %d  | queued: %d",
                len(all_page_files), skipped_count, len(queue))
    logger.info("batch_size=%d  concurrency=%d  max_retries=%d  force=%s",
                batch_size, concurrency, max_retries, force)
    logger.info("=" * 60)

    succeeded = 0
    failed_urls: list[str] = []
    run_start = time.time()

    try:
        for batch_idx in range(0, len(queue), batch_size):
            batch = queue[batch_idx:batch_idx + batch_size]
            batch_num = batch_idx // batch_size + 1
            total_batches = (len(queue) + batch_size - 1) // batch_size
            logger.info("--- Batch %d/%d  (%d page(s)) ---", batch_num, total_batches, len(batch))

            with ThreadPoolExecutor(max_workers=concurrency) as pool:
                futures: list[Future] = [
                    pool.submit(_process_page, pf, output_dir_path, client) for pf in batch
                ]
                for future in as_completed(futures):
                    page_file, url, audit, usage, error = future.result()
                    if error is None:
                        progress.record_success(url, usage, estimate_cost(usage, MODEL))
                        succeeded += 1
                        logger.info(
                            "  ok    %-44s overall=%.1f  $%.4f  cum=$%.4f",
                            page_file.name[:44],
                            (audit or {}).get("overall_score", 0.0),
                            estimate_cost(usage, MODEL)["total"],
                            progress.cost_total_usd,
                        )
                    else:
                        progress.record_failure(url, str(error))
                        failed_urls.append(url)
                        logger.error("  FAIL  %-44s  %s: %s",
                                     page_file.name[:44], type(error).__name__, error)

            progress.save()
            logger.info("Checkpoint saved after batch %d/%d", batch_num, total_batches)

    except KeyboardInterrupt:
        logger.warning("Interrupted by user — saving checkpoint and exiting")
        progress.save()
        raise

    # Write terminal failures to the log
    terminal_failed_urls = [
        url for url, info in progress.failed.items()
        if info.get("attempts", 0) > max_retries
    ]
    if terminal_failed_urls:
        failed_log_path.write_text(
            "\n".join(
                f"{u}\t{progress.failed[u].get('attempts', 0)}\t"
                f"{(progress.failed[u].get('errors') or [{}])[-1].get('error', '')}"
                for u in terminal_failed_urls
            ),
            encoding="utf-8",
        )

    wall_seconds = time.time() - run_start
    stats = {
        "total_queued": len(queue),
        "succeeded": succeeded,
        "failed": len(failed_urls),
        "skipped": skipped_count,
        "wall_seconds": wall_seconds,
        "avg_seconds_per_page": (wall_seconds / max(succeeded, 1)),
        "usage_totals": dict(progress.usage_totals),
        "cost_total_usd": round(progress.cost_total_usd, 4),
        "cost_breakdown_usd": {k: round(v, 4) for k, v in progress.cost_breakdown_usd.items()},
        "failed_urls": failed_urls,
        "failed_log_path": str(failed_log_path.resolve()) if terminal_failed_urls else "",
        "progress_path": str(progress_path.resolve()),
        "output_dir": str(output_dir_path.resolve()),
    }

    _print_runtime_summary(stats)
    return stats
