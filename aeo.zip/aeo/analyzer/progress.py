"""Checkpoint state for analyzer runs — supports resume after interruption."""

import json
import os
import threading
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path


USAGE_KEYS = ("input_tokens", "output_tokens", "cache_creation_input_tokens", "cache_read_input_tokens")


@dataclass
class Progress:
    """Thread-safe analyzer checkpoint backed by a JSON file."""

    path: Path
    started_at: float = field(default_factory=time.time)
    last_updated_at: float = 0.0
    completed_urls: list[str] = field(default_factory=list)
    failed: dict[str, dict] = field(default_factory=dict)
    usage_totals: dict[str, int] = field(default_factory=lambda: {k: 0 for k in USAGE_KEYS})
    cost_total_usd: float = 0.0
    cost_breakdown_usd: dict[str, float] = field(default_factory=lambda: {
        "input": 0.0, "output": 0.0, "cache_write": 0.0, "cache_read": 0.0
    })

    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False, compare=False)

    @classmethod
    def load_or_create(cls, path: str | Path) -> "Progress":
        p = Path(path)
        if p.exists():
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
                inst = cls(path=p)
                inst.started_at = data.get("started_at", time.time())
                inst.last_updated_at = data.get("last_updated_at", 0.0)
                inst.completed_urls = list(data.get("completed_urls", []))
                inst.failed = dict(data.get("failed", {}))
                inst.usage_totals = {**inst.usage_totals, **data.get("usage_totals", {})}
                inst.cost_total_usd = float(data.get("cost_total_usd", 0.0))
                inst.cost_breakdown_usd = {**inst.cost_breakdown_usd, **data.get("cost_breakdown_usd", {})}
                return inst
            except (json.JSONDecodeError, OSError):
                pass
        return cls(path=p)

    def is_completed(self, url: str) -> bool:
        return url in self.completed_urls

    def attempt_count(self, url: str) -> int:
        return self.failed.get(url, {}).get("attempts", 0)

    def has_failed_terminal(self, url: str, max_retries: int) -> bool:
        return self.attempt_count(url) > max_retries

    def record_success(self, url: str, usage: dict, cost: dict) -> None:
        with self._lock:
            if url not in self.completed_urls:
                self.completed_urls.append(url)
            self.failed.pop(url, None)
            for key in USAGE_KEYS:
                self.usage_totals[key] += int(usage.get(key, 0) or 0)
            for key in ("input", "output", "cache_write", "cache_read"):
                self.cost_breakdown_usd[key] += float(cost.get(key, 0.0))
            self.cost_total_usd += float(cost.get("total", 0.0))
            self.last_updated_at = time.time()

    def record_failure(self, url: str, error: str) -> None:
        with self._lock:
            entry = self.failed.get(url, {"attempts": 0, "errors": []})
            entry["attempts"] = entry.get("attempts", 0) + 1
            errors = entry.get("errors", [])
            errors.append({"ts": time.time(), "error": error})
            entry["errors"] = errors[-5:]
            self.failed[url] = entry
            self.last_updated_at = time.time()

    def backfill_existing_audits(self, output_dir: Path) -> int:
        """Mark already-saved audit JSONs in *output_dir* as completed. Returns count added."""
        added = 0
        with self._lock:
            seen = set(self.completed_urls)
            for f in sorted(output_dir.glob("*.json")):
                if f.name.startswith("_"):
                    continue
                try:
                    data = json.loads(f.read_text(encoding="utf-8"))
                except (json.JSONDecodeError, OSError):
                    continue
                if "issues" not in data:
                    continue
                url = data.get("url")
                if url and url not in seen:
                    self.completed_urls.append(url)
                    seen.add(url)
                    added += 1
        return added

    def save(self) -> None:
        with self._lock:
            data = {
                "started_at": self.started_at,
                "last_updated_at": self.last_updated_at,
                "completed_urls": self.completed_urls,
                "failed": self.failed,
                "usage_totals": self.usage_totals,
                "cost_total_usd": round(self.cost_total_usd, 4),
                "cost_breakdown_usd": {k: round(v, 4) for k, v in self.cost_breakdown_usd.items()},
            }
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        os.replace(tmp, self.path)
